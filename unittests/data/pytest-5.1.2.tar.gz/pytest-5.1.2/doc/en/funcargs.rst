
=======================================================
funcargs: resource injection and parametrization
=======================================================

pytest-2.3 introduces major refinements to fixture management
of which the funcarg mechanism introduced with pytest-2.0 remains
a core part.  The documentation has been refactored as well
and you can read on here:

- :ref:`fixtures`
- :ref:`parametrize`
- :ref:`funcargcompare`
