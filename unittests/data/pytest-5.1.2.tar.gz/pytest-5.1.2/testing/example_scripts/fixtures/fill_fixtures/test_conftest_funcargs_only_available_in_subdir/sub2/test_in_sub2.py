def test_2(arg2):
    pass
