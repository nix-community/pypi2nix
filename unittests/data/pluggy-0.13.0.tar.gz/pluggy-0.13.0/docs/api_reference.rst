:orphan:

Api Reference
=============

.. automodule:: pluggy
    :members:
    :undoc-members:
    :show-inheritance:


.. automethod:: pluggy.callers._Result.get_result

.. automethod:: pluggy.callers._Result.force_result

.. automethod:: pluggy.hooks._HookCaller.call_extra
