# coding: utf8
from __future__ import unicode_literals


LOOKUP = {
    "kaugnayan": "ugnay",
    "sangkatauhan": "tao",
    "kanayunan": "nayon",
    "pandaigdigan": "daigdig",
    "kasaysayan": "saysay",
    "kabayanihan": "bayani",
    "karuwagan": "duwag",
}
