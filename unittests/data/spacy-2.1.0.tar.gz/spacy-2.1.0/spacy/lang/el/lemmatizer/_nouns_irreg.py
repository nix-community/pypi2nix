# coding: utf8
from __future__ import unicode_literals


NOUNS_IRREG = {
    "λευτεριά": ("ελευθερία",),
    "καφέδες": ("καφές",),
    "ποιήματα": ("ποίημα",),
}
