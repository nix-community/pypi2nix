# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.da.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Apple overvejer at købe et britisk startup for 1 milliard dollar",
    "Selvkørende biler flytter forsikringsansvaret over på producenterne",
    "San Francisco overvejer at forbyde udbringningsrobotter på fortov",
    "London er en stor by i Storbritannien",
]
