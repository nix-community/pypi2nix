from .conll17_ud_eval import main as ud_evaluate  # noqa: F401
from .ud_train import main as ud_train  # noqa: F401
